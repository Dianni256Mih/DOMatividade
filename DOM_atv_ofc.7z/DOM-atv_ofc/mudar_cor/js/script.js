function alterarCor(cor) {
    document.body.style.backgroundColor = cor;
  }
  
  